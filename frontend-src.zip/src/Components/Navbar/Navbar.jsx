import React, { useContext, useRef, useState } from 'react'
import './Navbar.css'
import logo from '../Assets/logo.png'
import cart_icon from '../Assets/cart_icon.png'
import { Link } from 'react-router-dom'
import { ShopContext } from '../../Context/ShopContext'
import nav_dropdown from '../Assets/dropdown_arrow.png'

export const Navbar = () => {

    const[menu,setmenu] = useState('shop')
    const {gtci}=useContext(ShopContext);
    const menuRef=useRef();

    const dropdown_toggle=(e)=>{
        menuRef.current.classList.toggle('nav-menu-visiable');
        e.target.classList.toggle('open');
    }

  return (
    <div className='nav-bar'>
        <div className='nav-logo'>
            <img src={logo} alt=''></img>
            <p>SHOpIFY</p>
        </div>
        <img className='nav-dropdown' onClick={dropdown_toggle} src={nav_dropdown} alt="" />
        <ul ref={menuRef} className='nav-menu'>
            <li onClick={()=>{setmenu('ALL')}}><Link style={{textDecoration:'none' ,color:'black'}} to='/'>ALL</Link>{menu==='ALL'?<hr/>:<></>}</li>
            <li onClick={()=>{setmenu('HE')}}><Link style={{textDecoration:'none' ,color:'black'}} to='/HE'>HE</Link>{menu==='HE'?<hr/>:<></>}</li>
            <li onClick={()=>{setmenu('SHE')}}><Link style={{textDecoration:'none' ,color:'black'}} to='/SHE'>SHE</Link>{menu==='SHE'?<hr/>:<></>}</li>
            <li onClick={()=>{setmenu('CHUNMUN')}}><Link style={{textDecoration:'none' ,color:'black'}} to='/CHUNMUN'>CHUNMUN</Link>{menu==='CHUNMUN'?<hr/>:<></>}</li>
        </ul>
        <div className='nav-login-cart'>
            {localStorage.getItem('auth-token')
            ?<button onClick={()=>{localStorage.removeItem('auth-token');window.location.replace('/')}}>Logout</button>
            :<Link style={{textDecoration:'none'}} to='/Login'><button>Login</button></Link>}
            <Link style={{textDecoration:'none'}} to='/Cart'><img src={cart_icon} alt=''></img></Link>
            <div className="nav-cart-count">{gtci()}</div>
        </div>
    </div>
  )
}
