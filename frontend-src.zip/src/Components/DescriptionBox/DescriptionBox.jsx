import React from 'react'
import './DescriptionBox.css'

export const DescriptionBox = () => {
  return (
    <div className='descriptionbox'>
        <div className="descriptionbox-navigator">
            <div className="description-nav-box">Description</div>
            <div className="description-nav-box fade"> Reviews (122)</div>
        </div>
        <div className="descriptionbox-description">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit vero vel nobis esse dolor omnis voluptatum quasi beatae adipisci laudantium, molestias optio reiciendis ab odit sint dignissimos consequatur minus amet. Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus quaerat sint nemo nam sapiente cumque et amet tempore, iste saepe error nostrum quisquam unde quis architecto voluptate eveniet, atque eos.
            </p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque, quas? Ducimus, ipsum ullam, commodi dolorum deleniti maxime itaque cumque facere, nulla rem repudiandae recusandae natus tempore vel. Adipisci, sunt optio!</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia quis perferendis ab quo, rerum alias. Nulla deleniti architecto expedita ea autem sed mollitia. Porro dolor minus totam aliquam, expedita eum!</p>
        </div>
    </div>
  )
}
