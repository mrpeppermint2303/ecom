import './App.css';
import { BrowserRouter,Routes,Route} from 'react-router-dom';
import { LoginSignup } from './pages/LoginSignup/LoginSignup';
import { Navbar } from './pages/Navbar/Navbar';
import { WeatherInfo } from './pages/weather_info/WeatherInfo';
import { UserInfo } from './pages/UserInfo/UserInfo';
import { Myself } from './pages/Myself/Myself';
import { Notfound } from './pages/Notfound/Notfound';
import { UserProvider } from './Context/UserContext';

function App() {
  return (
    <div className="App">
      <UserProvider>
      <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path='/' element={<Myself />}/>
        <Route path='/Login' element={<LoginSignup />}/> 
        <Route path='/winfo' element={<WeatherInfo />}/>
        <Route path='/Ginfo' element={<UserInfo />}/>
        <Route path="*" element={<Notfound />} />
      </Routes>
      </BrowserRouter>
      </UserProvider>
    </div>
  );
}

export default App;
