import React from 'react'

export const Notfound = () => {
    return (
        <div>
          <h1>Oops!</h1>
          <p>The page you are looking for does not exist.</p>
          <button onClick={()=>{window.location.replace('/Login');localStorage.removeItem('auth-token');}}>Click here to go to Login...</button>
        </div>
      );
}
