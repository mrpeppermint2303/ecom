import React, { useEffect, useState } from 'react';
import { useUser } from '../../Context/UserContext';
import 'bootstrap/dist/css/bootstrap.min.css'
import './UserInfo.css'
import { useNavigate } from "react-router-dom";
import { Toaster,toast } from "react-hot-toast";


export const UserInfo = () => {

  const navigate = useNavigate();
  const { userData, setUserInfo } = useUser();
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
 
  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
    const response = await fetch('http://localhost:4000/uinfo', {
          headers: {
            'auth-token': localStorage.getItem('auth-token'),
          },
        });
        const data = await response.json();
        // console.log('user info response:', response)
        setUserInfo(data);
      } catch (error) {
        console.error('Error fetching user information', error);
      } finally {
        setLoading(false);
      }
    };
 
    fetchUserInfo();
  });

  const updateUserInfo = async (e) => {
    e.preventDefault();
    try {
        const response = await fetch('http://localhost:4000/updateUserInfo', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'auth-token': localStorage.getItem('auth-token'),
            },
            body: JSON.stringify({ name, email }),
        });

        const data = await response.json();
        console.log(data); // Handle the response accordingly
        toast.success('Information Updated')
        setUserInfo(data)
        setName('');
        setEmail('');
    } catch (error) {
        console.error('Error updating user information', error);
    }
};

const updatePassword = async (e) => {
  e.preventDefault()
    try {
        const response = await fetch('http://localhost:4000/updatePassword', {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'auth-token': localStorage.getItem('auth-token'),
            },
            body: JSON.stringify({ newPassword }),
        });

        const data = await response.json();
        console.log(data); // Handle the response accordingly
        toast.success('Password Updated');
        setNewPassword('');
    } catch (error) {
        console.error('Error updating password', error);
    }
};

const deleteAccount = async () => {
  try {
    const response = await fetch('http://localhost:4000/deleteAccount', {
      method: 'DELETE',
      headers: {
        'auth-token': localStorage.getItem('auth-token'),
      },
    });

    const data = await response.json();
    console.log(data); // Handle the response accordingly

    // Optionally, you may want to redirect the user after successful deletion
    if (data.success) {
      localStorage.removeItem('auth-token');
      navigate('/Login'); // Redirect to the login page or another appropriate route
      
    }
  } catch (error) {
    console.error('Error deleting user account', error);
    toast.error('Error deleting user account');
  }
};
  
  if(localStorage.getItem('auth-token')){
  return (
    <div className="container mt-5">
      
    {loading ? (
      <p>Loading user information...</p>
    ) : userData ? (
      <>
        <h1>User Information</h1>
        <p>Name: {userData.name}</p>
        <p>Email: {userData.email}</p>

        {/* Update user information form */}
        <form onSubmit={updateUserInfo} className="mt-4">
          <div className="mb-3">
            <label htmlFor="newName" className="form-label">
              New Name:
            </label>
            <input
              type="text"
              className="form-control"
              id="newName"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="newEmail" className="form-label">
              New Email:
            </label>
            <input
              type="email"
              className="form-control"
              id="newEmail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Update Information
          </button>
        </form>

        {/* Update password form */}
        <form onSubmit={updatePassword} className="mt-4">
          <div className="mb-3">
            <label htmlFor="newPassword" className="form-label">
              New Password:
            </label>
            <input
              type="password"
              className="form-control"
              id="newPassword"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Update Password
          </button>
        </form>

        {/* Delete account button */}
        <button onClick={deleteAccount} className="btn btn-danger mt-4">
          Delete Account
        </button>
      </>
    ) : (
      <p>Error fetching user information</p>
    )}
    <Toaster />
  </div>
  );
  }
  else{
    localStorage.removeItem('auth-token');
    window.location.replace('/Login');
  }
}
