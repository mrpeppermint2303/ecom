import React from 'react'
import './Navbar.css'
import { Link } from 'react-router-dom'
import { useNavigate } from "react-router-dom";

export const Navbar = () => {
  const navigate = useNavigate();
  return (
    <div className='nav-bar'>
        <div className='nav-login-cart'>
            {localStorage.getItem('auth-token')
            ?<>
            <button onClick={()=>{navigate('/winfo')}}>Dashboard</button>
            <button onClick={()=>{localStorage.removeItem('auth-token');navigate('/Login')}}>Logout</button>
            <button onClick={()=>{navigate('/Ginfo')}}>UserInfo</button></>
            :<Link style={{textDecoration:'none'}} to='/Login'><button>Weather App Login</button></Link>}
        </div>
    </div>
  )
}
