import React from 'react'
import './Myself.css'

export const Myself = () => {
  return (
    <div className='info'>
        <marquee behavior="alternate">This is a simple weather app with login and signup made by Akash Gupta - 2308319</marquee>
    </div>
  )
}
