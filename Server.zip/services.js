const port= 4000;
const express= require("express");
const app= express();
const mongoose= require("mongoose");
const jwt= require("jsonwebtoken");
const path= require("path");
const cors= require("cors");

app.use(express.json());
app.use(cors())

// Database Connection With MongoDB (EJqJShRYzZUK2puJ)
mongoose.connect("mongodb+srv://akashgupta9889:EJqJShRYzZUK2puJ@cluster0.vgoj2cj.mongodb.net/weather")
mongoose.connection.on('connected', () => {
    console.log('Connected to MongoDB');
  });
// API Creation

app.get("/",(req,res)=>{
    res.send("Express App is Running")
})


// Schema creating for User model

const Users = mongoose.model('Users',{
    name:{
        type:String,
        
    },
    email:{
        type:String,
        unique:true,
   
    },
    password:{
        type:String,
      
    },
    date:{
        type:Date,
        default:Date.now,
    }
})

// Creating Endpoint for registering the User
app.post('/signup', async(req,res)=>{
    let check=await Users.findOne({email:req.body.email});
    if(check){
        return res.status(400).json({success:false,errors:'existing user found with same email address'})
    }
    if(req.body.name!="" && req.body.email!="" && req.body.password!=""){
        const user = new Users({
            name:req.body.username,
            email:req.body.email,
            password:req.body.password,
            
        })
        console.log(user)

    await user.save();

    const data ={
        user:{
            id:user.id
        }
    }

    const token = jwt.sign(data,'secret_ecom');
    res.json({success:true,token})
    }
    else{
        return res.status(400).json({success:false,errors:'Fields should not be empty'})

    }


})

//Endpoint for user login
app.post('/login',async (req,res)=>{
    let user=await Users.findOne({email:req.body.email});
    if(user){
        const passCompare = req.body.password === user.password;
        if(passCompare){
            const data ={
                user:{
                    id:user.id
                }
            }
            const token =jwt.sign(data,'secret_ecom');
            res.json({success:true,token});
        }
        else{
            res.json({success:false,errors:"Wrong Password"})
        }
    }
    else{
        res.json({success:false,errors:"Wrong Email Address"})
    }
})

// for fetching and token verification of the user data middleware 
const toVerify=async(req,res,next)=>{
    const token=req.header('auth-token');
  
    if(!token){
        res.status(401).send({errors:"Please authenticate using valid token"})
    }
    else{
        try{
            const data = jwt.verify(token,'secret_ecom');
            req.user=data.user;
            next();
        }catch(error){
            res.status(401).send({errors:"Please authenticate using valid token"})
        }
    }
}

app.get('/uinfo', toVerify, async (req, res) => {
    try {
    const userData = await Users.findOne({ _id: req.user.id });
      res.json(userData);
    } catch (error) {
      res.status(500).json({ errors: 'Error fetching user information' });
    }
  });

  // Endpoint for updating user information
app.put('/updateUserInfo', toVerify, async (req, res) => {
    try {
        const { name, email } = req.body;
        let data={};
        if(name){data.name=name}
        if(email){data.email=email}
        // Update user information logic,
        console.log(data);
        await Users.updateOne({ _id: req.user.id }, data);
        
        res.json({ success: true, message: 'User information updated successfully' });
    } catch (error) {
        console.log(error)
    res.status(500).json({ success: false, error:error /*'Internal server error'*/ });
    }
});

// Endpoint for updating user password
app.patch('/updatePassword', toVerify, async (req, res) => {
    try {
        const { newPassword } = req.body;

        // Update user password logic
        await Users.updateOne({ _id: req.user.id }, { password: newPassword });

        res.json({ success: true, message: 'Password updated successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Endpoint for deleting the user account
app.delete('/deleteAccount', toVerify, async (req, res) => {
    try {
      // Delete user account logic
      await Users.findByIdAndDelete(req.user.id);
  
      res.json({ success: true, message: 'Account deleted successfully' });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Internal server error' });
    }
  });

app.listen(port,(error)=>{
    if(!error){
        console.log("Server Running on Port "+port)
    }
    else{
        console.log("Error : "+error)
        console.log('working')
    }
})